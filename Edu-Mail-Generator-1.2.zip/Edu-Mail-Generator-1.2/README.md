# Edu-Mail-Generator
Generate Free Edu Mail(s) within minutes

Currently this bot can create 20 Different Clg edu mails.

## Only For Educational Purpose ##
## ***Requirements***

- Python `3.7 or >`
- Python `pip`

## ***Installation***

	  python3 setup.py
It will download all required packages and webdrivers automatically based on your browsers versions (You need not to install them seprately)

## ***Usage***

	  python3 bot.py
Follow the instructions to get started with generating your own edu mail

## ***Features***

- One click install/setup.
- No programming knowledge needed (other then python3 with pip installed).
- Setup will install all webdrivers needed automatically based on your browsers.
- Many more features.

## ***Why should you use it ?***

- It saves the time by doing the work for you (It usually takes 15 to 20 minutes to fill a form manually)
- No limit on creating edu mails. You can create as much as you need (preferred to use in limits)
- Here are some of the benefits of having .edu email.


## ***GitHub Student Developer Pack***

- The first and biggest benefit of having a .EDU email address is the GitHub Student Developer Pack, the best free developer tools, and services for students. This student pack comes with 12 great offers and free services that may be useful to you, such as $15 Amazon AWS coupon, $50 Digital Ocean coupon, and much more.

## ***Take a look at the list below:***

- $15 Amazon AWS coupon
- $50 Digital Ocean coupon. It will be expired within 12 months after adding to your account – new account only.
- Bitnami: Offers the Business 3 plan for one year that typically cost $49 per month.
- Crowdflower: access to the Crowdflower platform.
- DNSimple: Offers the Personal hosted DNS plan for two years that typically charge $5 per month.
- GitHub: Offers unlimited private repositories while you are a student. Normally, GitHub charges $7 per month.
- $25 credit of HackHands, a live programming help that available 24/7.
- A suite of Microsoft Azure cloud services and developer tools: Microsoft Azure, Visual Studio Community and the rest of Microsoft developer tools, while you are a student.
NameCheap.com: Offer one year .ME domain name registration that costs $18.99 per year – and one year SSL certificate that costs $10 per year.
- Orchestrate: Access to the Developer account that costs $49 per month, while you are a student. It’s a complete database portfolio, includes search, time-series events, geolocation, and graph queries through an API.
SendGrid: Offers the Student plan with 15,000 free emails per month, while you are a student.
Travis CI: Access the Private builds that charge you $69 per month, while you are a student.

## ***Amazon Student Pack***
- When you use a .EDU email account and sign up for Amazon Student account – you will be able to use this fake edu email for Amazon Prime for free for six months, which has many benefits:

- Free TWO-DAY shipping on many Amazon products.
- Get unlimited instant streaming of movies, TV shows, and music.
- Access exclusive deals for students.
- Unlimited photo storage with Amazon Prime Photos.

## ***LastPass***
- LastPass offers six months of the LastPass Premium for any users with a .EDU email address.

## ***Newegg Premier***
- Grab one year of Newegg Premier that costs you $50. Just sign up Newegg Premier account with your student email account.

## ***Apple***
- You will help yourself saving a lot of money by using the .EDU email address to purchase products from Apple. There are changes to save up to $200 on Apple computers.

## ***Microsoft DreamSpark***
- Grab Microsoft DreamSpark with plenty of useful software and Microsoft Office 365 subscription for free.

- Benefit list of .edu email is not limited in these only there are many other benefits like free domain name and much more.
